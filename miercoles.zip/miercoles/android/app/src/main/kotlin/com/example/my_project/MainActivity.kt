package com.mycompany.miercoles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
